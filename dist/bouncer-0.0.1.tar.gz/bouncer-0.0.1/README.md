# SE/SQS Event Monitor Package

Poll SQS and show bounce/complaint events in MyCE